--------------------
Wimpy Flac
--------------------
version 0.1

--------------------
Basic Installation
--------------------
To use on your page, reference the "wimpy.flac.js" file 
just after the reference to the "wimpy.js" engine.

	<!-- Wimpy Engine -->
	<script src="wimpy.js"></script>

	<!-- Wimpy FLAC Plugin (must be below wimpy.js) -->
	<script src="wimpy.flac.js"></script>
	
--------------------
More Info:
--------------------
http://www.wimpyplayer.com/docs/common/file_formats_FLAC.html
